from flask import Flask, render_template, request
from graph import GRAPH, dijkstra

app = Flask(__name__)


@app.route("/", methods=["GET", "POST"])
def home():

    locations = list(GRAPH.keys())

    path = []
    distance = None
    error = None
    start = ""
    end = ""

    if request.method == "POST":

        start = request.form.get("start")
        end = request.form.get("end")

        if start == end:
            error = "Start aur destination alag hone chahiye."

        else:
            path, distance = dijkstra(GRAPH, start, end)

            if not path:
                error = "Route nahi mila."

    return render_template(
        "index.html",
        locations=locations,
        path=path,
        distance=distance,
        error=error,
        start=start,
        end=end
    )


if __name__ == "__main__":
    app.run(debug=True)