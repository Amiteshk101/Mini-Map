console.log("Mini Maps JavaScript Loaded");

document.addEventListener("DOMContentLoaded", function () {

    const start = document.querySelector('select[name="start"]');
    const end = document.querySelector('select[name="end"]');

    if (start && end) {

        start.addEventListener("change", function () {
            console.log("Starting location:", this.value);
        });

        end.addEventListener("change", function () {
            console.log("Destination:", this.value);
        });
    }

});