import heapq


# Graph: locations aur unke beech distance
GRAPH = {
    "Dr.KNMIET": {
        "Modinagar": 4,
        "Ghaziabad": 10
    },

    "Modinagar": {
        "Dr.KNMIET": 4,
        "Ghaziabad": 6,
        "Meerut": 8
    },

    "Ghaziabad": {
        "Dr.KNMIET": 10,
        "Modinagar": 6,
        "Delhi": 5
    },

    "Meerut": {
        "Modinagar": 8,
        "Delhi": 12
    },

    "Delhi": {
        "Ghaziabad": 5,
        "Meerut": 12
    }
}


def dijkstra(graph, start, end):
    # Starting distance
    distances = {node: float("inf") for node in graph}
    distances[start] = 0

    # Previous node store karne ke liye
    previous = {node: None for node in graph}

    # Priority Queue
    priority_queue = [(0, start)]

    while priority_queue:

        current_distance, current_node = heapq.heappop(priority_queue)

        # Agar destination mil gaya
        if current_node == end:
            break

        # Old distance ignore karo
        if current_distance > distances[current_node]:
            continue

        # Neighbours check karo
        for neighbour, weight in graph[current_node].items():

            distance = current_distance + weight

            # Shorter path mil gaya
            if distance < distances[neighbour]:

                distances[neighbour] = distance
                previous[neighbour] = current_node

                heapq.heappush(
                    priority_queue,
                    (distance, neighbour)
                )

    # Path create karna
    path = []
    current = end

    while current is not None:
        path.append(current)
        current = previous[current]

    path.reverse()

    # Agar path available nahi hai
    if path[0] != start:
        return [], float("inf")

    return path, distances[end]